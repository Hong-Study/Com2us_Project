USE ApiDatabase;

CREATE TABLE user_game_data(
    id INT PRIMARY KEY,
    level INT NOT NULL,
    exp INT NOT NULL,
    gold INT NOT NULL,
    win INT NOT NULL,
    lose INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);